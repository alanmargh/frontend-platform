import { loadRemoteModule } from '@angular-architects/native-federation';
import { Routes } from '@angular/router';

export const appRoutes: Routes = [
  {
    path: 'dashboard',
    loadComponent: () => loadRemoteModule({
        remoteName: 'dashboard',
        exposedModule: './Component',
        remoteEntry: 'http://localhost:4100/remoteEntry.js'
      }).then((esm) => esm.AppComponent)
      
      // import('dashboard/Component').then(m => m.AppComponent)
  },
  {
    path: 'application-analyzer',
    loadComponent: () => loadRemoteModule({
      remoteName: 'application-analyzer',
      exposedModule: './Component',
    }).then((esm) => esm.AppComponent),
    // import('application-analyzer/Component').then(m => m.AppComponent)
  },
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
];